# SDXL Image Generation Workflow - Visual Reference

## Current Workflow (After Fixes) ✅

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    TASK CREATION (User Input)                          │
│                   "Write about Making Muffins"                         │
└────────────────────────┬────────────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                  SLUG GENERATION & DUPLICATE CHECK                      │
│              slug = "making-delicious-muffins"                          │
│         ┌──────────────────────────────────────────┐                    │
│         │ NEW: Check if post exists                │                    │
│         │ SELECT * FROM posts WHERE slug = ?       │                    │
│         │ (Prevents UniqueViolationError)          │                    │
│         └──────────────────────────────────────────┘                    │
│                         │                                               │
│            ┌────────────┴────────────┐                                 │
│            │                         │                                 │
│       EXISTS ✅                  NEW ✅                                │
│            │                         │                                 │
│     REUSE EXISTING               CREATE NEW                           │
│     (No crash)                   (Normal flow)                         │
└────────────┬───────────┬─────────────────────────────────────────────┘
             │           │
             │           ▼
             │    ┌──────────────────────────────────────────────┐
             │    │      CONTENT GENERATION (LLM)                │
             │    │   - Generate article title                   │
             │    │   - Generate article content                 │
             │    │   - Generate excerpt                         │
             │    │   - Generate image prompt                    │
             │    └──────┬───────────────────────────────────────┘
             │           │
             │           ▼
             │    ┌──────────────────────────────────────────────┐
             │    │   IMAGE GENERATION (SDXL/PEXELS)             │
             │    │   - Call SDXL on GPU (20-30 sec)            │
             │    │   - OR fetch from Pexels API                │
             │    └──────┬───────────────────────────────────────┘
             │           │
             │           ▼
             │    ┌──────────────────────────────────────────────┐
             │    │   NEW: SAVE TO DOWNLOADS FOLDER             │
             │    │   Path: ~/Downloads/                         │
             │    │          glad-labs-generated-images/         │
             │    │   File: sdxl_20240112_153045_task123.png    │
             │    │                                              │
             │    │   ⭕ IMAGE NOW PERSISTED LOCALLY ⭕         │
             │    └──────┬───────────────────────────────────────┘
             │           │
             │           ▼
             │    ┌──────────────────────────────────────────────┐
             │    │   RESPONSE TO FRONTEND (NEW FIELDS)          │
             │    │   {                                          │
             │    │     success: true,                           │
             │    │     image_url: "/Users/.../sdxl_*.png",     │
             │    │     local_path: "/Users/.../sdxl_*.png",    │
             │    │     preview_mode: true,          NEW ✨      │
             │    │     source: "sdxl-local-preview" NEW ✨      │
             │    │   }                                          │
             │    └──────┬───────────────────────────────────────┘
             │           │
             └───────────┼──────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────────────┐
│              FRONTEND: SHOW IMAGE PREVIEW (TO IMPLEMENT)                │
│         User sees image from ~/Downloads/ (local preview)               │
│         Not yet in CDN - awaiting approval                              │
│                                                                          │
│         [ 🔄 Regenerate ] [ ✅ Approve & Publish ]                      │
└────┬────────────────────────────┬───────────────────┬──────────────────┘
     │                            │                   │
     │                    APPROVE ✅              (Waiting)
     │                            │
     │                            ▼
     │        ┌──────────────────────────────────────────────┐
     │        │  NEW ENDPOINT: POST /api/media/approve-image │
     │        │  (TO IMPLEMENT)                              │
     │        │                                              │
     │        │  1. Read local image file                    │
     │        │  2. Upload to Cloudinary CDN                 │
     │        │  3. Get CDN URL back                         │
     │        │  4. UPDATE posts table:                      │
     │        │     featured_image_url = CDN_URL             │
     │        │     status = "published"                     │
     │        │  5. Delete local file (optional)             │
     │        └──────────┬───────────────────────────────────┘
     │                   │
     │                   ▼
     │        ┌──────────────────────────────────────────────┐
     │        │    POST STATUS: PUBLISHED ✅                 │
     │        │                                              │
     │        │    posts.featured_image_url =               │
     │        │    "https://res.cloudinary.com/glad-labs/..."│
     │        │                                              │
     │        │    posts.status = "published"                │
     │        └──────────────────────────────────────────────┘
     │
     │ REGENERATE ↩️  (Optional)
     │
     ▼
┌─────────────────────────────────────────────────────────────────────────┐
│         NEW ENDPOINT: POST /api/media/generate-image-variations          │
│         (TO IMPLEMENT - For multi-image selection)                       │
│                                                                          │
│  Request:                                                                │
│  {                                                                       │
│    prompt: "a beautiful sunset",                                        │
│    num_variations: 3,                                                   │
│    task_id: "task123"                                                   │
│  }                                                                       │
│                                                                          │
│  Backend:                                                                │
│  ▼ Generate variation 1 → Save to Downloads/sdxl_*_var1.png           │
│  ▼ Generate variation 2 → Save to Downloads/sdxl_*_var2.png           │
│  ▼ Generate variation 3 → Save to Downloads/sdxl_*_var3.png           │
│  (Total: ~60-90 seconds sequential)                                     │
│                                                                          │
│  Response:                                                               │
│  {                                                                       │
│    success: true,                                                       │
│    images: [                                                            │
│      { path: ".../sdxl_*_var1.png", variation_number: 1 },            │
│      { path: ".../sdxl_*_var2.png", variation_number: 2 },            │
│      { path: ".../sdxl_*_var3.png", variation_number: 3 }             │
│    ]                                                                     │
│  }                                                                       │
│                                                                          │
│  Frontend:                                                               │
│  ▼ Show 3 images in grid                                               │
│  ▼ Radio buttons to select best one                                    │
│  ▼ Click "Approve Selected" → Call approve-image with selected image  │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## Image Storage Flow

```
                    STEP 1: GENERATION
                            │
                            ▼
                    ┌───────────────────┐
                    │ SDXL/Pexels Gen   │
                    │ 20-30 sec         │
                    └────────┬──────────┘
                             │
                             ▼
                    ┌───────────────────────────────────────────┐
                    │ DOWNLOADS FOLDER (NEW LOCATION)           │
                    │ ~/Downloads/glad-labs-generated-images/   │
                    │                                           │
                    │ Files created:                            │
                    │ • sdxl_20240112_153045_task123.png       │
                    │ • sdxl_20240112_153045_task123_var1.png │
                    │ • sdxl_20240112_153045_task123_var2.png │
                    │ • sdxl_20240112_153045_task123_var3.png │
                    │                                           │
                    │ ⭕ IMAGES PERSIST HERE UNTIL APPROVAL ⭕  │
                    └────────┬─────────────────────────────────┘
                             │
                    ┌────────┴────────┐
                    │                 │
                    ▼                 ▼
            LOCAL PREVIEW       (Wait for approval)
            Frontend displays    User can:
            image from file      • Review image
                                • Regenerate
                                • Choose variation
                                │
                                ▼
                        USER APPROVES ✅
                                │
                                ▼
                    ┌───────────────────────────────────────┐
                    │ APPROVAL ENDPOINT                     │
                    │ /api/media/approve-image              │
                    │                                       │
                    │ 1. Read local file                    │
                    │ 2. Upload to Cloudinary               │
                    │    res.cloudinary.com/...             │
                    │ 3. Delete local file ✓                │
                    └────────┬────────────────────────────┘
                             │
                             ▼
                    ┌───────────────────┐
                    │ CDN STORAGE       │
                    │ (Permanent)       │
                    │                   │
                    │ https://          │
                    │ res.cloudinary.com│
                    │ /glad-labs/...    │
                    └───────┬───────────┘
                            │
                            ▼
                    ┌─────────────────────────┐
                    │ DATABASE               │
                    │ posts table            │
                    │                        │
                    │ featured_image_url =   │
                    │ "https://...cdn.url"   │
                    │ status = "published"   │
                    └────────────────────────┘
```

---

## Error Handling Flow

```
┌──────────────────────────────────────────────────────────┐
│ TASK CREATION WITH DUPLICATE TITLE                       │
└─────────────────────────────┬──────────────────────────┘
                              │
                              ▼
                    ┌─────────────────────────┐
                    │ Generate slug           │
                    │ "making-muffins"        │
                    └──────────┬──────────────┘
                               │
                ┌──────────────┴──────────────┐
                │                             │
         FIRST TIME                    SECOND TIME
                │                             │
                ▼                             ▼
    ┌──────────────────────┐      ┌─────────────────────────┐
    │ Check database       │      │ Check database          │
    │ SELECT WHERE slug=?  │      │ SELECT WHERE slug=?     │
    │ Result: NOT FOUND    │      │ Result: FOUND ✅        │
    │ Status: 🟢 NEW       │      │ Status: 🟢 EXISTS       │
    └──────┬───────────────┘      └──────┬──────────────────┘
           │                             │
           ▼                             ▼
    ┌──────────────────────┐      ┌─────────────────────────┐
    │ INSERT new post      │      │ REUSE existing post     │
    │ Status: ✅ Created   │      │ Skip INSERT             │
    │ No error             │      │ Status: ⚠️  Log warning │
    │                      │      │ No UniqueViolation ✅   │
    └──────────────────────┘      └─────────────────────────┘
           │                             │
           └──────────────┬──────────────┘
                          │
                    Continue flow
                    (Both succeed)

OLD BEHAVIOR:
┌──────────────────────┐
│ FIRST: INSERT ✅     │
├──────────────────────┤
│ SECOND:              │
│ UniqueViolationError │
│ 💥 CRASH 💥         │
└──────────────────────┘

NEW BEHAVIOR:
┌──────────────────────┐
│ FIRST: INSERT ✅     │
├──────────────────────┤
│ SECOND:              │
│ REUSE ✅             │
│ No error ✅          │
└──────────────────────┘
```

---

## Response Model Evolution

### Before (Minimal)

```json
{
  "success": true,
  "image_url": "https://...",
  "image": {
    "url": "https://...",
    "source": "cloudinary"
  },
  "message": "✅ Image found"
}
```

### After (With Local Info) ✨

```json
{
  "success": true,
  "image_url": "/Users/user/Downloads/glad-labs-generated-images/sdxl_*.png",
  "local_path": "/Users/user/Downloads/glad-labs-generated-images/sdxl_*.png",
  "preview_mode": true,
  "image": {
    "url": "/Users/user/Downloads/glad-labs-generated-images/sdxl_*.png",
    "source": "sdxl-local-preview"
  },
  "message": "✅ Image generated and saved locally (preview mode). Review and approve to publish.",
  "generation_time": 28.5
}
```

---

## Database Schema (No Changes Needed)

```
┌─────────────────────────────────────────────┐
│ posts TABLE (existing schema)                │
├─────────────────────────────────────────────┤
│ id (pk)                                     │
│ title                                       │
│ slug (UNIQUE) ← Duplicate check on this     │
│ content                                     │
│ excerpt                                     │
│ featured_image_url ← Stores CDN URL after   │
│ status                                      │
│ created_at                                  │
│ updated_at                                  │
└─────────────────────────────────────────────┘

New Queries Added:
• SELECT * FROM posts WHERE slug = ? (Check for duplicates)
• UPDATE posts SET featured_image_url=?, status=? (After approval)
```

---

## Timeline: What's Done vs. What's Next

```
┌───────────────────────────────────────────────────────────────┐
│                      PHASE 1: COMPLETE ✅                    │
├───────────────────────────────────────────────────────────────┤
│                                                               │
│  ✅ Duplicate slug prevention                                │
│  ✅ Image local storage                                      │
│  ✅ Response model with local_path                           │
│  ✅ Removed CDN auto-upload                                  │
│                                                               │
│  Status: Ready for testing                                   │
│  Time: ~2.5 hours to implement + document                   │
│                                                               │
└───────────────────────────────────────────────────────────────┘

             ⬇️ PHASE 2: READY TO START ⏳ ⬇️

┌───────────────────────────────────────────────────────────────┐
│                    PHASE 2: TO IMPLEMENT                     │
├───────────────────────────────────────────────────────────────┤
│                                                               │
│  ⏳ Approval endpoint (upload local to CDN)                  │
│     Time: 15 min | Template: Ready ✅                        │
│                                                               │
│  ⏳ Multi-image variations endpoint                          │
│     Time: 20 min | Template: Ready ✅                        │
│                                                               │
│  ⏳ UI components (preview, approve, select)                 │
│     Time: 20 min | Examples: Ready ✅                        │
│                                                               │
│  ⏳ End-to-end testing                                       │
│     Time: 15 min                                             │
│                                                               │
│  Status: All templates provided, ready to implement          │
│  Total Time: 70 minutes                                      │
│                                                               │
└───────────────────────────────────────────────────────────────┘

             ⬇️ OPTIONAL: PHASE 3 (Polish) ⬇️

┌───────────────────────────────────────────────────────────────┐
│                PHASE 3: OPTIMIZATION (Future)               │
├───────────────────────────────────────────────────────────────┤
│                                                               │
│  • Add cleanup logic (delete local after upload)             │
│  • Auto-cleanup old images (>7 days)                         │
│  • Progress bar for multi-image generation                   │
│  • Caching improvements                                      │
│  • Performance optimization                                  │
│                                                               │
│  Time: ~35 minutes (optional)                                │
│                                                               │
└───────────────────────────────────────────────────────────────┘
```

---

## Quick Reference: Which File Does What?

```
🔵 database_service.py
   ├─ NEW: get_post_by_slug()        ← Check for duplicates
   └─ NEW: update_post()              ← Update after approval

🟢 task_routes.py
   └─ MODIFIED: _execute_and_publish_task()  ← Add dup check

🟡 media_routes.py
   ├─ MODIFIED: ImageGenerationResponse     ← Add fields
   ├─ MODIFIED: generate_featured_image()   ← Change path
   ├─ REMOVED: CDN upload logic             ← Keep local
   └─ MODIFIED: Return statements           ← Add metadata

🟣 media_routes.py (TO IMPLEMENT)
   ├─ NEW: approve_image()           ← Upload to CDN
   └─ NEW: generate_image_variations()  ← Multi-image

🟠 Oversight Hub UI (TO IMPLEMENT)
   └─ UPDATE: TaskDetail component   ← Add preview/approve
```

---

## Success Criteria: Before vs. After

```
┌──────────────────────────────────────────────────────────────┐
│                        BEFORE                               │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│ ❌ Duplicate title → UniqueViolationError crash             │
│ ❌ Image generated but not saved locally                    │
│ ❌ No way to preview before publishing                      │
│ ❌ No way to regenerate or compare images                   │
│ ❌ Images uploaded immediately (no review cycle)            │
│ ❌ No local file persistence                                │
│                                                              │
└──────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────┐
│                        AFTER PHASE 1                         │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│ ✅ Duplicate title → Reused, no error                      │
│ ✅ Image saved to Downloads folder                          │
│ ✅ Response includes local_path for preview                │
│ ✅ Ready for multi-image feature                            │
│ ✅ Images stay local until approved                         │
│ ✅ Full file persistence with traceable names              │
│                                                              │
└──────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────┐
│                    AFTER PHASE 2 (Coming)                   │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│ ✅ Everything from Phase 1 +                               │
│ ✅ Approval button works (uploads to CDN)                  │
│ ✅ Can generate multiple variations                         │
│ ✅ Can select best image before approval                   │
│ ✅ Complete approval workflow functional                   │
│ ✅ UI shows image preview and controls                     │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

---

**Visual Reference Complete** 🎨  
See other documents for detailed implementation guides.
